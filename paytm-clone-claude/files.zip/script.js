// =============================================
// PAYTM.AI — SCRIPT v2.0
// =============================================

// ---- DOM References ----
const chatbotContainer  = document.getElementById('chatbot-container');
const chatbotMinimized  = document.getElementById('chatbot-minimized');
const chatMessages      = document.getElementById('chat-messages');
const chatInput         = document.getElementById('chat-input');
const sendBtn           = document.getElementById('send-btn');
const micBtn            = document.getElementById('mic-btn');
const listeningOverlay  = document.getElementById('listening-overlay');
const quickReplies      = document.getElementById('quick-replies');
const radarIcon         = document.getElementById('refund-radar-minimized');

// ---- State ----
let isVoiceSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
let recognition      = null;
let silenceTimer     = null;
let autoVoiceTriggered = false;
let activePDFDoc     = null;

// ---- Mock User Data ----
const userData = {
    name: 'Chaitanya',
    brands: 'boAt, Myntra',
    extraCount: 4,
    recentFailedTx: { merchant: 'Zomato', amount: '₹340', id: 'TXN89324021' },
    refundLodged: false,
    wallet: '₹2,450.00'
};

// ---- Mock Transactions ----
const mockTransactions = [
    { id: 'PTM-10061', date: '03 Apr 2026, 10:24 AM', merchant: 'Zomato',        amount: '₹340.00', cashback: '₹0',    status: 'Failed' },
    { id: 'PTM-10062', date: '02 Apr 2026, 08:55 AM', merchant: 'Uber Rides',    amount: '₹125.50', cashback: '₹10',   status: 'Success' },
    { id: 'PTM-10063', date: '01 Apr 2026, 06:30 PM', merchant: 'Amazon India',  amount: '₹1,450.00',cashback:'₹50',   status: 'Success' },
    { id: 'PTM-10064', date: '31 Mar 2026, 08:00 PM', merchant: 'Jio Recharge',  amount: '₹399.00', cashback: '₹0',    status: 'Success' },
    { id: 'PTM-10065', date: '30 Mar 2026, 11:45 AM', merchant: 'Starbucks',     amount: '₹450.00', cashback: '₹20',   status: 'Success' },
    { id: 'PTM-10066', date: '29 Mar 2026, 03:10 PM', merchant: 'Myntra',        amount: '₹899.00', cashback: '₹100',  status: 'Success' },
    { id: 'PTM-10067', date: '28 Mar 2026, 09:00 AM', merchant: 'Rapido',        amount: '₹72.00',  cashback: '₹36',   status: 'Success' },
    { id: 'PTM-10068', date: '27 Mar 2026, 02:00 PM', merchant: 'BSES Electricity','amount':'₹1,845.00','cashback':'₹0',status:'Success'},
    { id: 'PTM-10069', date: '26 Mar 2026, 07:30 PM', merchant: 'Netflix',       amount: '₹649.00', cashback: '₹0',    status: 'Success' },
    { id: 'PTM-10070', date: '25 Mar 2026, 12:15 PM', merchant: 'Swiggy',        amount: '₹487.00', cashback: '₹25',   status: 'Success' },
];

// =============================================
// TOGGLE CHATBOT
// =============================================

function toggleChatbot() {
    chatbotContainer.classList.toggle('expanded');
    const isExpanded = chatbotContainer.classList.contains('expanded');

    if (isExpanded) {
        chatbotMinimized.classList.add('hidden');
        if (radarIcon) radarIcon.style.display = 'none';
        resetSilenceTimer();
    } else {
        setTimeout(() => {
            chatbotMinimized.classList.remove('hidden');
            if (radarIcon) { radarIcon.style.display = ''; }
        }, 350);
        clearTimeout(silenceTimer);
    }
}

// =============================================
// ADULT FEMALE VOICE — TTS
// =============================================

function speakText(text, callback) {
    if (!('speechSynthesis' in window)) {
        if (callback) callback();
        return;
    }

    window.speechSynthesis.cancel();
    const msg = new SpeechSynthesisUtterance();
    msg.text = text.replace(/\*\*/g, '').replace(/[\*\#\_]/g, ''); // strip markdown

    // Mature adult female voice settings
    msg.pitch  = 0.88;   // lower than default (1.0) = deeper, more adult
    msg.rate   = 0.87;   // slightly slower = more composed, authoritative
    msg.volume = 1.0;

    const loadAndSpeak = () => {
        const voices = window.speechSynthesis.getVoices();
        // Priority list: mature female voices preferred
        const preferredNames = [
            'Google UK English Female',
            'Microsoft Hazel',
            'Microsoft Susan',
            'Microsoft Zira',
            'Samantha',
            'Victoria',
            'Karen',
            'Moira',
        ];

        let chosen = null;
        for (const name of preferredNames) {
            chosen = voices.find(v => v.name.includes(name));
            if (chosen) break;
        }

        if (!chosen) {
            chosen = voices.find(v =>
                (v.name.toLowerCase().includes('female') ||
                 v.name.toLowerCase().includes('woman')) &&
                (v.lang.startsWith('en'))
            );
        }

        if (chosen) {
            msg.voice = chosen;
        } else {
            msg.lang = 'en-GB'; // UK English default tends to sound more mature
        }

        msg.onend = () => { if (callback) callback(); };
        window.speechSynthesis.speak(msg);
    };

    // Voices may not be loaded yet
    if (window.speechSynthesis.getVoices().length > 0) {
        loadAndSpeak();
    } else {
        window.speechSynthesis.onvoiceschanged = loadAndSpeak;
    }
}

// =============================================
// INITIALIZATION
// =============================================

window.onload = () => {
    applyDynamicButtonColors();

    // Nav scroll effect
    window.addEventListener('scroll', () => {
        const nav = document.querySelector('.global-desktop-nav');
        if (nav) {
            nav.classList.toggle('scrolled', window.scrollY > 20);
        }
    });

    // --- Chatbot appears after 1.2s (minimized only) ---
    setTimeout(() => {
        chatbotContainer.classList.remove('state-hidden');
        chatbotContainer.style.visibility = 'visible';
        chatbotContainer.style.opacity    = '1';

        // Pre-load the greeting so it's ready when user opens
        appendMessage('bot', `👋 Hi **${userData.name}**! Welcome back to Paytm! I'm **Maya**, your AI assistant. How can I help you today?`);
        setTimeout(() => {
            appendMessage('bot', `🛎️ <b>Heads up!</b> Your <b>${userData.brands}</b> and +${userData.extraCount} more vouchers are expiring soon. <a href="#" style="color:var(--paytm-light-blue);font-weight:700;" onclick="claimVouchers(event)">Tap to claim!</a>`);
        }, 600);

        // --- Refund Radar rolls out like a wheel after 2.2s ---
        setTimeout(() => {
            if (radarIcon) radarIcon.classList.add('visible');
        }, 2200);

    }, 1200);

    // ---- Speech Recognition Setup ----
    if (isVoiceSupported) {
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SR();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-IN';

        recognition.onstart = () => {
            micBtn.classList.add('active');
            listeningOverlay.classList.remove('hidden');
        };

        recognition.onresult = (e) => {
            const transcript = e.results[0][0].transcript;
            chatInput.value = transcript;
            micBtn.classList.remove('active');
            listeningOverlay.classList.add('hidden');
            handleSend();
        };

        recognition.onerror = recognition.onend = () => {
            micBtn.classList.remove('active');
            listeningOverlay.classList.add('hidden');
        };
    }

    // ---- Event Listeners ----
    sendBtn.addEventListener('click', handleSend);
    chatInput.addEventListener('keypress', e => { if (e.key === 'Enter') handleSend(); });
    chatInput.addEventListener('input', () => clearTimeout(silenceTimer));
    micBtn.addEventListener('click', () => startListening(true));
};

function claimVouchers(e) {
    e.preventDefault();
    appendMessage('bot', '🎁 Awesome! We\'ve automatically added all the offers to your account. Happy shopping!');
}

// =============================================
// QUICK REPLY BUTTON COLOURS
// =============================================

function applyDynamicButtonColors() {
    const palette = [
        { bg: '#e6f7ff', color: '#0052cc', border: '#bce2f5' },
        { bg: '#fff0f6', color: '#c70057', border: '#ffb3d5' },
        { bg: '#f0fff4', color: '#1a7f4b', border: '#b2f0ce' },
        { bg: '#fff8e1', color: '#8a6200', border: '#ffe082' },
        { bg: '#f3eeff', color: '#5b21b6', border: '#d8b4fe' },
        { bg: '#fff3ed', color: '#c24200', border: '#ffd0b3' },
        { bg: '#e8f5e9', color: '#2e7d32', border: '#a5d6a7' },
        { bg: '#fce4ec', color: '#880e4f', border: '#f48fb1' },
        { bg: '#e3f2fd', color: '#1565c0', border: '#90caf9' },
        { bg: '#f9fbe7', color: '#558b2f', border: '#c5e1a5' },
        { bg: '#fde8e8', color: '#b91c1c', border: '#fca5a5' },
        { bg: '#ede9fe', color: '#4c1d95', border: '#c4b5fd' },
    ];

    const btns = quickReplies.querySelectorAll('button');
    btns.forEach((btn, i) => {
        const style = palette[i % palette.length];
        btn.style.backgroundColor = style.bg;
        btn.style.color = style.color;
        btn.style.border = `1px solid ${style.border}`;
    });
}

// =============================================
// VOICE RECOGNITION
// =============================================

function startListening(triggerVibration = true) {
    if (triggerVibration && navigator.vibrate) {
        navigator.vibrate([150, 80, 150]);
    }

    if (isVoiceSupported && recognition) {
        try { recognition.start(); } catch (e) { /* already started */ }
    } else {
        listeningOverlay.classList.remove('hidden');
        setTimeout(() => {
            listeningOverlay.classList.add('hidden');
            chatInput.value = 'My last 5 transactions';
            handleSend();
        }, 2200);
    }
}

// ---- Auto-speak after 30s silence ----
function resetSilenceTimer() {
    clearTimeout(silenceTimer);
    if (!autoVoiceTriggered) {
        silenceTimer = setTimeout(() => {
            if (chatbotContainer.classList.contains('expanded')) {
                autoVoiceTriggered = true;
                const audioText = 'How may I help you today? I can assist with payments, refunds, bookings, and more.';
                appendMessage('bot', audioText);
                speakText(audioText, () => startListening(true));
            }
        }, 30000);
    }
}

// =============================================
// SEND & PROCESS MESSAGES
// =============================================

function handleSend() {
    const text = chatInput.value.trim();
    if (!text) return;
    appendMessage('user', text);
    chatInput.value = '';
    clearTimeout(silenceTimer);

    showTypingIndicator();
    setTimeout(() => {
        removeTypingIndicator();
        processAIResponse(text);
    }, 900 + Math.random() * 700);
}

function sendQuickReply(text) {
    chatInput.value = text;
    handleSend();
}

function appendMessage(role, html) {
    const div = document.createElement('div');
    div.classList.add('message', role);
    div.innerHTML = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator() {
    removeTypingIndicator();
    const div = document.createElement('div');
    div.classList.add('message', 'bot');
    div.id = 'typing-indicator';
    div.innerHTML = '<div class="typing-indicator"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div>';
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function removeTypingIndicator() {
    const el = document.getElementById('typing-indicator');
    if (el) el.remove();
}

function appendActionCard(title, desc) {
    const div = document.createElement('div');
    div.classList.add('message', 'bot');
    div.innerHTML = `
        <div class="bot-action-box">
            <h5><i class="fas fa-check-circle" style="color:#22c55e;"></i> ${title}</h5>
            <p>${desc}</p>
        </div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// =============================================
// AI RESPONSE ROUTING
// =============================================

function processAIResponse(userInput) {
    const q = userInput.toLowerCase();

    // ---- Refund / Failed Payment ----
    if (q.includes('refund') || q.includes('failed') || q.includes("didn't go through") ||
        q.includes('money not') || q.includes('deducted') || q.includes('not received')) {
        handleRefundRadarIntent();
        return;
    }

    // ---- Track / Status ----
    if ((q.includes('track') || q.includes('status')) && (q.includes('refund') || q.includes('complaint') || q.includes('ticket'))) {
        if (!userData.refundLodged) {
            appendMessage('bot', 'No refund ticket found yet. Let me scan your transactions now...');
            handleRefundRadarIntent();
        } else {
            appendMessage('bot', `✅ Your refund for **${userData.recentFailedTx.merchant}** (Ticket: <b>${userData.recentFailedTx.id}</b>) is actively in process and will reflect in your account within **24–48 hours**. No action needed from your side!`);
        }
        return;
    }

    // ---- Lodge Complaint ----
    if (q.includes('lodge') || q.includes('complaint') || q.includes('report issue')) {
        appendMessage('bot', '📝 Let\'s lodge your complaint. Please describe the issue briefly:');
        appendMessage('bot', `
            <div class="bot-action-box">
                <h5><i class="fas fa-exclamation-circle" style="color:#f59e0b;"></i> Quick Complaint Options</h5>
                <p>• <b>Transaction Issue</b> — Payment debited but not credited<br>
                • <b>Wallet Issue</b> — Wallet balance incorrect<br>
                • <b>Recharge Issue</b> — Recharge not activated<br>
                • <b>Account Issue</b> — Login / KYC problem<br><br>
                Type or tap the relevant issue above, or describe in your own words.</p>
            </div>`);
        return;
    }

    // ---- FAQs ----
    if (q.includes('faq') || q.includes('help') || q.includes('how to') || q.includes('what is')) {
        appendMessage('bot', '📚 **Frequently Asked Questions**');
        appendMessage('bot', `
            <div class="bot-action-box">
                <h5><i class="fas fa-question-circle" style="color:#3b82f6;"></i> Top FAQs</h5>
                <p>
                    🔵 <b>How do I add money to wallet?</b> — Go to Wallet → Add Money.<br><br>
                    🔵 <b>Is UPI transfer free?</b> — Yes, 100% free, 24×7.<br><br>
                    🔵 <b>How to check balance?</b> — Wallet section shows live balance.<br><br>
                    🔵 <b>Cashback not received?</b> — It takes 3–5 working days after eligibility confirmation.<br><br>
                    🔵 <b>How to change UPI PIN?</b> — Go to Profile → Linked Banks → Reset UPI PIN.
                </p>
            </div>`);
        return;
    }

    // ---- QR Pay ----
    if (q.includes('qr') || q.includes('scan')) {
        appendMessage('bot', '📲 **Paying via QR Code is super easy!**\n\n1️⃣ Tap **"Scan QR Code"** on the dashboard.\n2️⃣ Point your camera at any UPI QR code.\n3️⃣ Enter the amount → confirm with your UPI PIN.\n\n✅ Works at all stores, online, and even on Paytm Soundbox merchants!');
        return;
    }

    // ---- Pay via Phone Number ----
    if (q.includes('phone number') || q.includes('mobile number') || q.includes('pay mobile') || q.includes('send money')) {
        appendMessage('bot', '📞 **Pay via Phone Number:**\n\n1️⃣ Go to **Send Money** on the dashboard.\n2️⃣ Enter the recipient\'s registered mobile number.\n3️⃣ Enter amount → UPI PIN to confirm.\n\n💡 Both sender & receiver must have UPI registered. Instant transfer, 24×7 free!');
        return;
    }

    // ---- Ride Booking: Uber / Ola / Rapido ----
    if (q.includes('uber') || q.includes('ola') || q.includes('rapido') || q.includes('cab') || q.includes('ride') || q.includes('auto')) {
        appendRideOffers();
        return;
    }

    // ---- Flight Booking ----
    if (q.includes('flight') || q.includes('fly') || q.includes('air ticket')) {
        appendFlightOffers();
        return;
    }

    // ---- Train Booking ----
    if (q.includes('train') || q.includes('irctc') || q.includes('railway')) {
        appendTrainOffers();
        return;
    }

    // ---- Bus Booking ----
    if (q.includes('bus')) {
        appendMessage('bot', '🚌 **Book Bus Tickets via Paytm**\n\nGet ₹150 off on bus tickets with code **BUS150** (min. booking ₹500).\n\nTap the "Bus Tickets" option in the booking section above!');
        return;
    }

    // ---- Movie / Events ----
    if (q.includes('movie') || q.includes('event') || q.includes('ticket') || q.includes('concert')) {
        appendMessage('bot', '🎬 **Movie & Event Tickets**\n\nPaytm connects you to **District** for all movie & event bookings!\n\n🎟️ Use code **MOVIE100** for ₹100 off on movie tickets.\n\n👉 Tap "Movie Tickets" or "Event Tickets" on the dashboard to proceed. You\'ll be seamlessly redirected to District app/website.');
        return;
    }

    // ---- Food Order ----
    if (q.includes('food') || q.includes('order') || q.includes('swiggy') || q.includes('zomato') || q.includes('eat')) {
        appendFoodOffers();
        return;
    }

    // ---- Transaction History / Statement ----
    if (q.includes('history') || q.includes('transaction') || q.includes('statement') || q.includes('last ')) {
        const numMatch = q.match(/last\s+(\d+)|recent\s+(\d+)|(\d+)\s+transact/);
        const limit = numMatch ? parseInt(numMatch[1] || numMatch[2] || numMatch[3]) : 5;
        const safeLimit = Math.min(limit, mockTransactions.length);

        appendMessage('bot', `⏳ Fetching your last **${safeLimit} transactions** and building your statement... Please wait a moment.`);
        generatePDFWithPreview(safeLimit);
        return;
    }

    // ---- Vouchers / Offers ----
    if (q.includes('voucher') || q.includes('cashback') || q.includes('offer') || q.includes('coupon')) {
        appendMessage('bot', `🎁 **Your Active Vouchers & Offers:**\n\n💙 **boAt** — ₹500 off on orders above ₹2,000 (expires in 2 days!)\n🛍️ **Myntra** — 30% extra cashback on fashion (expires tomorrow!)\n🍕 **Dominos** — Buy 1 Get 1 on all Large Pizzas\n🚗 **Rapido** — 50% off next 3 rides\n\nTap **"View All Offers"** in the Paytm app to see all ${userData.extraCount + 2} offers!`);
        return;
    }

    // ---- Thanks ----
    if (q.includes('thanks') || q.includes('thank you') || q.includes('great') || q.includes('awesome')) {
        appendMessage('bot', "You're most welcome! 😊 It was my pleasure to help. Have a wonderful day! Is there anything else I can assist you with?");
        return;
    }

    // ---- Wallet Balance ----
    if (q.includes('balance') || q.includes('wallet')) {
        appendMessage('bot', `💳 Your **Paytm Wallet** balance is **${userData.wallet}**.\n\nWould you like to add money, send money, or view recent transactions?`);
        return;
    }

    // ---- Fallback ----
    appendMessage('bot', "I'm specialized in the Paytm ecosystem! 😊 Try asking about:\n\n• 💳 Payments & Refunds\n• 📊 Transaction History\n• ✈️ Flights, 🚂 Trains, 🚗 Rides\n• 🍔 Food Orders\n• 🎁 Vouchers & Cashback\n• ⚠️ Lodge / Track Complaint");
}

// =============================================
// OFFER CARDS IN CHAT
// =============================================

function appendRideOffers() {
    appendMessage('bot', '🚗 Great choice! Book rides via Paytm and earn exclusive rewards:');
    const div = document.createElement('div');
    div.classList.add('message', 'bot');
    div.style.maxWidth = '96%';
    div.innerHTML = `
        <div class="offer-chat-card">
            <div class="offer-title">🎉 Ride Booking Offers — Active Now!</div>
            <ul class="offer-list">
                <li>🎁 <span><b>50% Cashback</b> (up to ₹75) on your first 3 rides booked via Paytm.</span></li>
                <li>🎟️ <span>Earn <b>2 exclusive Paytm vouchers</b> worth ₹100 each on booking now.</span></li>
                <li>⭐ <span>Get <b>5× Paytm Points</b> on every ride — redeem on bills & recharges.</span></li>
                <li>⚡ <span>Offer valid for <b>next 48 hours only.</b> Don't miss out!</span></li>
            </ul>
            <div class="offer-redirect-btn">
                <a href="https://www.olacabs.com" target="_blank"><i class="fas fa-car"></i> Book Ola</a>
                <a href="https://www.uber.com/in/en/" target="_blank"><i class="fas fa-taxi"></i> Book Uber</a>
                <a href="https://rapido.bike" target="_blank"><i class="fas fa-motorcycle"></i> Book Rapido</a>
            </div>
        </div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function appendFlightOffers() {
    appendMessage('bot', '✈️ Let\'s get you flying! Here are your exclusive Paytm flight offers:');
    const div = document.createElement('div');
    div.classList.add('message', 'bot');
    div.style.maxWidth = '96%';
    div.innerHTML = `
        <div class="offer-chat-card">
            <div class="offer-title">✈️ Flight Booking Offers!</div>
            <ul class="offer-list">
                <li>💙 <span>Extra <b>10% off</b> with code <b>PAYTMFLY10</b> on all domestic flights.</span></li>
                <li>🎁 <span><b>₹500 instant cashback</b> on international flights above ₹20,000.</span></li>
                <li>🏦 <span>0% convenience fee when paying via Paytm Wallet.</span></li>
            </ul>
            <div class="offer-redirect-btn">
                <a href="#tickets-section"><i class="fas fa-plane"></i> Book Flight Now</a>
            </div>
        </div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function appendTrainOffers() {
    appendMessage('bot', '🚂 Booking trains via Paytm? You\'ve got great perks!');
    const div = document.createElement('div');
    div.classList.add('message', 'bot');
    div.style.maxWidth = '96%';
    div.innerHTML = `
        <div class="offer-chat-card">
            <div class="offer-title">🚂 Train Booking Offers!</div>
            <ul class="offer-list">
                <li>🆓 <span><b>Zero convenience fee</b> on IRCTC bookings via Paytm.</span></li>
                <li>🎁 <span><b>₹50 cashback</b> on Tatkal bookings using Paytm UPI.</span></li>
                <li>⭐ <span>Earn <b>2× Paytm Points</b> on every train ticket booked.</span></li>
            </ul>
            <div class="offer-redirect-btn">
                <a href="#tickets-section"><i class="fas fa-train"></i> Book Train Now</a>
            </div>
        </div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function appendFoodOffers() {
    appendMessage('bot', '🍔 Hungry? Pay via Paytm and save big on your next order!');
    const div = document.createElement('div');
    div.classList.add('message', 'bot');
    div.style.maxWidth = '96%';
    div.innerHTML = `
        <div class="offer-chat-card">
            <div class="offer-title">🍕 Food Order Offers!</div>
            <ul class="offer-list">
                <li>🍔 <span><b>20% cashback</b> (up to ₹150) on Swiggy orders via Paytm.</span></li>
                <li>🍕 <span><b>15% off</b> on Zomato Gold orders when paid via Paytm Wallet.</span></li>
                <li>🧁 <span>Get a free dessert voucher on orders above ₹599 on Swiggy.</span></li>
            </ul>
            <div class="offer-redirect-btn">
                <a href="https://www.swiggy.com" target="_blank"><i class="fas fa-utensils"></i> Order on Swiggy</a>
                <a href="https://www.zomato.com" target="_blank"><i class="fas fa-hamburger"></i> Order on Zomato</a>
            </div>
        </div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// =============================================
// REFUND RADAR
// =============================================

function handleRefundRadarIntent() {
    if (userData.refundLodged) {
        appendMessage('bot', `✅ Your refund ticket **${userData.recentFailedTx.id}** for **${userData.recentFailedTx.amount}** is already in process. Funds will reflect within **24–48 hours**.`);
        return;
    }

    appendMessage('bot', '🔍 Activating **Refund Radar™**... Scanning your recent transactions now...');
    showTypingIndicator();

    setTimeout(() => {
        removeTypingIndicator();
        const tx = userData.recentFailedTx;
        userData.refundLodged = true;
        appendMessage('bot',
            `I detected a **failed transaction** of **${tx.amount}** to **${tx.merchant}**.\n\n` +
            `✅ I have raised a refund ticket on your behalf. Your money is safe and will be credited back within **24–48 hours**. No stress!`
        );
        appendActionCard(`Ticket #RFD-8942-SUCCESS`, `Refund lodged for ${tx.amount} → ${tx.merchant}. Type "track complaint" anytime for status.`);
    }, 2200);
}

function handleRadarClick() {
    if (!chatbotContainer.classList.contains('expanded')) {
        toggleChatbot();
    }
    if (radarIcon) radarIcon.style.display = 'none';

    setTimeout(() => {
        if (!userData.refundLodged) {
            appendMessage('bot', '👋 Welcome to **Refund Radar™**! Let me scan your transactions for any issues.');
            handleRefundRadarIntent();
        } else {
            appendMessage('user', 'Track my complaint');
            showTypingIndicator();
            setTimeout(() => {
                removeTypingIndicator();
                processAIResponse('track complaint');
            }, 900);
        }
    }, 450);
}

// =============================================
// PAYMENT MOCK MODAL
// =============================================

function openPaymentMock(title) {
    const modal      = document.getElementById('payment-modal');
    const titleEl    = document.getElementById('payment-title');
    const statusEl   = document.getElementById('payment-status');
    const loader     = document.querySelector('.payment-loader');
    const closeBtn   = document.getElementById('close-payment-btn');

    titleEl.innerText  = title;
    statusEl.innerText = '🔒 Connecting securely...';
    loader.className   = 'payment-loader';
    closeBtn.classList.add('hidden');
    modal.classList.remove('hidden');

    setTimeout(() => {
        statusEl.innerText = '⚡ Processing payment...';
        setTimeout(() => {
            loader.className = 'payment-loader success';
            statusEl.innerText = '🎉 Payment Successful!';
            closeBtn.classList.remove('hidden');

            // Trigger voucher claim bubble
            showVoucherClaimBubble();
        }, 2000);
    }, 1400);
}

function closePaymentMock() {
    document.getElementById('payment-modal').classList.add('hidden');
}

// =============================================
// VOUCHER CLAIM BUBBLE (after payment success)
// =============================================

function showVoucherClaimBubble() {
    const tooltip = document.getElementById('claim-tooltip');
    if (!tooltip) return;
    tooltip.classList.remove('hidden');

    // Auto-dismiss after 12 seconds
    setTimeout(() => {
        tooltip.classList.add('hidden');
    }, 12000);

    // If chatbot is open, also send a message
    if (chatbotContainer.classList.contains('expanded')) {
        setTimeout(() => {
            appendMessage('bot', '🎉 **Transaction Complete!** You\'ve earned **cashback & vouchers** from this payment! Check your **Offers** section to claim them. 🎁');
        }, 500);
    }
}

// =============================================
// PDF GENERATION — WITH PREVIEW (3-4s delay)
// =============================================

function generatePDFWithPreview(limit) {
    const previewModal   = document.getElementById('pdf-preview-modal');
    const iframe         = document.getElementById('pdf-iframe');
    const buildingState  = document.getElementById('pdf-building-state');

    // Show modal with building state
    if (buildingState) buildingState.classList.remove('hidden');
    if (iframe) iframe.classList.add('hidden');
    previewModal.classList.remove('hidden');

    const delay = 3200 + Math.random() * 800; // 3.2 – 4.0s

    setTimeout(() => {
        if (!window.jspdf) {
            appendMessage('bot', '❌ PDF library unavailable. Please try again.');
            previewModal.classList.add('hidden');
            return;
        }

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
        const txns = mockTransactions.slice(0, limit);

        // ---- Header ----
        doc.setFillColor(0, 41, 112);
        doc.rect(0, 0, 210, 32, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(18);
        doc.text('Paytm', 14, 14);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Transaction Statement', 14, 21);
        doc.setFontSize(9);
        doc.text(`Generated: ${new Date().toLocaleString('en-IN')}`, 130, 14);
        doc.text(`Account: ${userData.name}`, 130, 21);
        doc.text(`Wallet Balance: ${userData.wallet}`, 130, 28);

        // ---- Summary box ----
        doc.setFillColor(240, 247, 255);
        doc.roundedRect(14, 38, 182, 18, 3, 3, 'F');
        doc.setTextColor(0, 41, 112);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.text(`Showing last ${limit} transaction${limit > 1 ? 's' : ''}`, 20, 48);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(80, 80, 80);
        doc.text(`Period: ${txns[txns.length - 1].date.split(',')[0]} – ${txns[0].date.split(',')[0]}`, 20, 54);

        // ---- Table header ----
        let y = 64;
        doc.setFillColor(15, 74, 138);
        doc.rect(14, y - 6, 182, 10, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.text('Txn ID',    16, y);
        doc.text('Date',      44, y);
        doc.text('Merchant',  90, y);
        doc.text('Amount',   144, y);
        doc.text('Cashback', 165, y);
        doc.text('Status',   185, y);

        // ---- Rows ----
        y += 10;
        txns.forEach((tx, i) => {
            if (i % 2 === 0) {
                doc.setFillColor(246, 250, 255);
                doc.rect(14, y - 6, 182, 10, 'F');
            }

            doc.setFont('helvetica', 'normal');
            doc.setTextColor(30, 30, 30);
            doc.setFontSize(8.5);
            doc.text(tx.id,       16, y);
            doc.text(tx.date.substring(0, 11), 44, y);
            doc.text(tx.merchant, 90, y);
            doc.text(tx.amount,  144, y);
            doc.text(tx.cashback,165, y);

            // Colour-coded status
            if (tx.status === 'Success') {
                doc.setTextColor(21, 128, 61);
            } else {
                doc.setTextColor(185, 28, 28);
            }
            doc.setFont('helvetica', 'bold');
            doc.text(tx.status, 185, y);
            doc.setTextColor(30, 30, 30);

            // Row separator
            doc.setDrawColor(220, 230, 245);
            doc.line(14, y + 4, 196, y + 4);
            y += 12;
        });

        // ---- Footer ----
        y += 6;
        doc.setFillColor(0, 186, 242);
        doc.rect(0, 280, 210, 17, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(8);
        doc.text('This is a computer-generated simulated statement. © Paytm.AI 2026', 14, 290);

        // ---- Preview in iframe ----
        activePDFDoc = doc;
        const blobUrl = doc.output('bloburl');
        window.activePDFBlobUrl = blobUrl;

        if (buildingState) buildingState.classList.add('hidden');
        if (iframe) {
            iframe.classList.remove('hidden');
            iframe.src = blobUrl;
        }

        appendMessage('bot', '✅ Your statement is ready! **Preview it in the popup** — download or print when needed.');
    }, delay);
}

function closePDFModal() {
    document.getElementById('pdf-preview-modal').classList.add('hidden');
}

function downloadActivePDF() {
    if (activePDFDoc) {
        activePDFDoc.save('Paytm_Statement.pdf');
    }
}

function printActivePDF() {
    const iframe = document.getElementById('pdf-iframe');
    if (iframe && iframe.contentWindow) {
        iframe.contentWindow.focus();
        iframe.contentWindow.print();
    }
}
